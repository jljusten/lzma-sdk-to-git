// MyUnknown.h

#ifndef __MYUNKNOWN_H
#define __MYUNKNOWN_H

#ifdef WIN32

// #include <guiddef.h>
#include <basetyps.h>
#include <unknwn.h>

#else 
#include "MyWindows.h"
#endif
  
#endif
