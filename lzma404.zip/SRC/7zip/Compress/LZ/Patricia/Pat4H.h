// Pat4H.h

#ifndef __PAT4H__H
#define __PAT4H__H

#undef PAT_CLSID
#define PAT_CLSID CLSID_CMatchFinderPat4H

#undef PAT_NAMESPACE
#define PAT_NAMESPACE NPat4H

#define __AUTO_REMOVE
#define __NODE_4_BITS
#define __HASH_3

#include "Pat.h"
#include "PatMain.h"

#undef __AUTO_REMOVE
#undef __NODE_4_BITS
#undef __HASH_3

#endif

