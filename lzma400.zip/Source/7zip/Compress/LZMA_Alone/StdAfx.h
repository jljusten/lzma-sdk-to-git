// stdafx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#include <windows.h>
#include <stdio.h>

// #pragma warning(disable:4786)

#endif 
