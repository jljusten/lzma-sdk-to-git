// LzmaBench.h

#ifndef __LzmaBench_h
#define __LzmaBench_h

int LzmaBenchmark(UInt32 numIterations, UInt32 dictionarySize);

#endif
