// HC2.h

#ifndef __HC2__H
#define __HC2__H

#undef HC_CLSID
#define HC_CLSID CLSID_CMatchFinderHC2

#undef HC_NAMESPACE
#define HC_NAMESPACE NHC2

#include "HCMF.h"
#include "HCMFMain.h"

#endif

