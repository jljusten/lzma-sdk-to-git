// StdAfx.h

#ifndef __STDAFX_H
#define __STDAFX_H

#ifdef WIN32
#include <windows.h>
#endif

#endif 
